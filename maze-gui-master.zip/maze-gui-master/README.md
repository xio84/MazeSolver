MazeGUI
=============

Generates a maze of arbitrary size and solves it using depth first search. "Screenshot.png" is a screenshot of the program.

To compile
-------
Simply use the makefile.

To run
-------
    java MazeGUI <size>

    java MazeGUI 40

